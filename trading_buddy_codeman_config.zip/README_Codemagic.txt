
Trading Buddy - Codemagic Build Instructions
--------------------------------------------
1. Upload this project to a GitHub repository (private or public).
2. Go to https://codemagic.io and sign up with GitHub/Google.
3. Connect your GitHub repo to Codemagic.
4. Codemagic will detect codemagic.yaml and automatically set up the workflow.
5. Start build -> wait few minutes -> download APK from Codemagic build artifacts.

You will find the APK in:
  build/app/outputs/flutter-apk/app-release.apk

This way you don't need any terminal or Flutter installed locally.
